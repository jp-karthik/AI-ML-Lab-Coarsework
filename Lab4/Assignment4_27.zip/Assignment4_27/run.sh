#!/bin/sh
python 27.py $1
