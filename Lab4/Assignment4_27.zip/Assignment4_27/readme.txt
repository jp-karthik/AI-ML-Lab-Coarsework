=> For executing the program we need a input file of any name with a .txt extension.

=> The first line of the input file must contain the string "euclidian" or "noneuclidian".

=> The corresponding next line must contain the number of cities N present in the graph.

=> Next N lines must contain the respective x and y coordinates of each city seperated by a space.

=> Next N lines must contain the distance of every other city from the current city. Each entry in a line must be seperated with blank space.

=> During executing the run.sh file an additional argument has to be passed i.e. the input file name (location).

=> Example : bash run.sh euc_100.txt (if the input file is present in the same directory as that of run.sh and 27.py)

=> After executing this command, the python file will execute and corresponding outputs will be displayed.
